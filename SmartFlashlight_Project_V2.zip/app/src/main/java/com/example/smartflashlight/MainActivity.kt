package com.example.smartflashlight

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var isFlashOn = false
    private var hasTorchLevelSupport = false

    private lateinit var btnToggle: Button
    private lateinit var seekBarBrightness: SeekBar
    private lateinit var brightnessText: TextView
    private lateinit var timerText: TextView
    private lateinit var inputCustomMinutes: EditText
    private lateinit var btnStartCustomTimer: Button
    private lateinit var btnCancelTimer: Button

    private var countdownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggle = findViewById(R.id.btnToggle)
        seekBarBrightness = findViewById(R.id.seekBarBrightness)
        brightnessText = findViewById(R.id.brightnessText)
        timerText = findViewById(R.id.timerText)
        inputCustomMinutes = findViewById(R.id.inputCustomMinutes)
        btnStartCustomTimer = findViewById(R.id.btnStartCustomTimer)
        btnCancelTimer = findViewById(R.id.btnCancelTimer)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && cameraId != null) {
                val chars = cameraManager.getCameraCharacteristics(cameraId!!)
                val level = chars.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL)
                hasTorchLevelSupport = level != null && level > 1
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (cameraId == null) {
            Toast.makeText(this, "هاتفك لا يدعم فلاش الكاميرا!", Toast.LENGTH_LONG).show()
        }

        btnToggle.setOnClickListener {
            toggleFlash()
        }

        seekBarBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                brightnessText.text = "شدة الإضاءة: $progress%"
                if (isFlashOn && hasTorchLevelSupport && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    setTorchBrightness(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnStartCustomTimer.setOnClickListener {
            val str = inputCustomMinutes.text.toString().trim()
            val mins = str.toIntOrNull()
            if (mins != null && mins > 0) {
                startTimer(mins * 60 * 1000L, "$mins دقيقة")
            } else {
                Toast.makeText(this, "الرجاء إدخال عدد دقائق صحيح", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancelTimer.setOnClickListener {
            cancelTimer()
        }
    }

    private fun toggleFlash() {
        val id = cameraId
        if (id == null) {
            Toast.makeText(this, "لا يوجد فلاش متاح", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (isFlashOn) {
                cameraManager.setTorchMode(id, false)
                isFlashOn = false
                btnToggle.text = "تشغيل الفلاش 💡"
                btnToggle.setBackgroundColor(android.graphics.Color.parseColor("#1DB954"))
                cancelTimer()
            } else {
                val progress = seekBarBrightness.progress
                if (hasTorchLevelSupport && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    setTorchBrightness(progress)
                } else {
                    cameraManager.setTorchMode(id, true)
                }
                isFlashOn = true
                btnToggle.text = "إيقاف الفلاش 🛑"
                btnToggle.setBackgroundColor(android.graphics.Color.parseColor("#E53935"))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ في تشغيل الفلاش", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setTorchBrightness(progress: Int) {
        val id = cameraId ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                val chars = cameraManager.getCameraCharacteristics(id)
                val maxLevel = chars.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                val targetLevel = ((progress / 100f) * maxLevel).toInt().coerceIn(1, maxLevel)
                cameraManager.turnOnTorchWithStrengthLevel(id, targetLevel)
            } catch (_: Exception) {
                cameraManager.setTorchMode(id, true)
            }
        }
    }

    private fun startTimer(durationMs: Long, label: String) {
        if (!isFlashOn) {
            toggleFlash()
        }
        countdownTimer?.cancel()
        countdownTimer = object : CountDownTimer(durationMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val mins = millisUntilFinished / 60000
                val secs = (millisUntilFinished % 60000) / 1000
                timerText.text = "⏰ الوقت المتبقي للإغلاق: %02d:%02d".format(mins, secs)
            }

            override fun onFinish() {
                timerText.text = "⏰ انتهى الوقت!"
                if (isFlashOn) {
                    toggleFlash()
                }
            }
        }.start()
        Toast.makeText(this, "تم ضبط المؤقت لمدة $label", Toast.LENGTH_SHORT).show()
    }

    private fun cancelTimer() {
        countdownTimer?.cancel()
        timerText.text = "⏰ المؤقت معطل"
        Toast.makeText(this, "تم إلغاء المؤقت", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        countdownTimer?.cancel()
        if (isFlashOn) {
            cameraId?.let {
                try {
                    cameraManager.setTorchMode(it, false)
                } catch (_: Exception) {}
            }
        }
    }
}
