package com.example.flashlightapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private var torchOn = false
    private var brightness = 50
    private var timer: CountDownTimer? = null
    private var remainingMillis = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("flashlight", Context.MODE_PRIVATE)
        brightness = prefs.getInt("brightness", 50)

        val status = findViewById<TextView>(R.id.statusText)
        val toggle = findViewById<Button>(R.id.toggleButton)
        val brightnessBar = findViewById<SeekBar>(R.id.brightnessBar)
        val brightnessText = findViewById<TextView>(R.id.brightnessText)
        val timerBar = findViewById<SeekBar>(R.id.timerBar)
        val timerText = findViewById<TextView>(R.id.timerText)

        brightnessBar.progress = brightness
        brightnessText.text = "الشدة: $brightness%"

        toggle.setOnClickListener {
            if (!hasCameraPermission()) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
                return@setOnClickListener
            }
            torchOn = !torchOn
            applyTorch()
            updateUi(status, toggle)
        }

        brightnessBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                brightness = value.coerceAtLeast(1)
                brightnessText.text = "الشدة: $brightness%"
                prefs.edit().putInt("brightness", brightness).apply()
                if (torchOn) applyTorch()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        findViewById<Button>(R.id.lowButton).setOnClickListener { setBrightness(25, brightnessBar, brightnessText) }
        findViewById<Button>(R.id.mediumButton).setOnClickListener { setBrightness(50, brightnessBar, brightnessText) }
        findViewById<Button>(R.id.highButton).setOnClickListener { setBrightness(100, brightnessBar, brightnessText) }

        val startTimer: (Int) -> Unit = { minutes ->
            if (!torchOn) {
                torchOn = true
                applyTorch()
                updateUi(status, toggle)
            }
            timer?.cancel()
            remainingMillis = minutes * 60_000L
            timer = object : CountDownTimer(remainingMillis, 1000) {
                override fun onTick(ms: Long) {
                    remainingMillis = ms
                    val m = ms / 60000
                    val s = (ms % 60000) / 1000
                    timerText.text = "سيتم الإيقاف بعد %02d:%02d".format(m, s)
                }
                override fun onFinish() {
                    torchOn = false
                    applyTorch()
                    updateUi(status, toggle)
                    timerText.text = "تم إيقاف الفلاش"
                }
            }.start()
        }

        findViewById<Button>(R.id.timer5).setOnClickListener { startTimer(5) }
        findViewById<Button>(R.id.timer10).setOnClickListener { startTimer(10) }
        findViewById<Button>(R.id.timer30).setOnClickListener { startTimer(30) }

        timerBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser && value > 0) startTimer(value)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        findViewById<Button>(R.id.cancelTimer).setOnClickListener {
            timer?.cancel()
            timerText.text = "تم إلغاء المؤقت"
        }
    }

    private fun setBrightness(value: Int, bar: SeekBar, text: TextView) {
        brightness = value
        bar.progress = value
        text.text = "الشدة: $value%"
        getSharedPreferences("flashlight", Context.MODE_PRIVATE)
            .edit().putInt("brightness", value).apply()
        if (torchOn) applyTorch()
    }

    private fun updateUi(status: TextView, toggle: Button) {
        status.text = if (torchOn) "الفلاش مفتوح" else "الفلاش مغلق"
        toggle.text = if (torchOn) "إيقاف الفلاش" else "تشغيل الفلاش"
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun applyTorch() {
        val cameraManager = getSystemService(CameraManager::class.java)
        val cameraId = cameraManager.cameraIdList.firstOrNull {
            cameraManager.getCameraCharacteristics(it)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: run {
            Toast.makeText(this, "لا يوجد فلاش في هذا الجهاز", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                val max = cameraManager.getCameraCharacteristics(cameraId)
                    .get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                if (max > 1 && torchOn) {
                    cameraManager.turnTorchOn(cameraId, (brightness * max / 100).coerceAtLeast(1))
                } else {
                    cameraManager.setTorchMode(cameraId, torchOn)
                }
            } else {
                cameraManager.setTorchMode(cameraId, torchOn)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر التحكم بالفلاش", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
        if (torchOn) {
            torchOn = false
            applyTorch()
        }
    }
}